<template>
  <div class="hello">
    A
    <input type="text" v-model="a">
    <div><router-link to='/B'>to B</router-link></div>
    <div><router-link to='/C'>to C</router-link></div>

    <p>A,B,C</p>

    <p>A->B->A A不刷新</p>
    
    <p>A->C->A A刷新</p>
    
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'A',
  props: {
    msg: String
  },
  data(){
    return{
      a:''
    }
  },
  activated(){
    console.log('activated')
  }
}
</script>

