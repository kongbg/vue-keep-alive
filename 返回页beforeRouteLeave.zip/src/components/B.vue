<template>
  <div class="hello">
    B
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'B',
  props: {
    msg: String
  },
  beforeRouteLeave (to, from, next) {
    if (to.name === 'A') {
       to.meta.keepAlive = true
    }
    next()
  }
}
</script>

