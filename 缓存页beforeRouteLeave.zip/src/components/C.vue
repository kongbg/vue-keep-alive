<template>
  <div class="hello">
    C
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'C',
  props: {
    msg: String
  }
}
</script>

